//#ifndef LAB_3_PO
//#define LAB_3_PO
//
//
//void LED_Bar_Init(void);
//void setLED(uint32_t pot);
//uint16_t readPot(int pin);
//#endif
#ifndef DRIVEBASE_H
#define DRIVEBASE_H

// Header for Drive Base

// Port List 
/*

(Drive) H-Bridge:
LEFTFORWARD: IN1, Y10
LEFTREVERSE: IN2, Y12
RIGHTFORWARD: IN3, Y04
RIGHTREVERSE: IN4, X11

Bumpers:
TOPRIGHTBUMP: V3
TOPLEFTBUMP: V4
BOTRIGHTBUMP: V5
BOTLEFTBUMP: V6

TapeSensors:
TOPRIGHTTAPE: W3
TOPLEFTTAPE: W4
BOTRIGHTTAPE: W5
BOTLEFTTAPE: W6

TrackSensors:
TOPTRACK: W7
BOTTRACK: W8

*/


//brush motor#define LEFT_DIR_TRIS _TRISB3
//#define LEFT_DIR_INV_TRIS _TRISB2
#define BRUSH_MOTOR_PWM PWM_PORTZ06 
#define BRUSH_FORWARD_TRIS PORTW05_TRIS//LATBbits.LATB3
#define BRUSH_BACKWARD_TRIS PORTW06_TRIS //LATBbits.LATB2
#define BRUSH_FORWARD_SET PORTW05_LAT
#define BRUSH_BACKWARD_SET PORTW06_LAT


#define DOOR_MOTOR_PWM PWM_PORTX11 
#define DOOR_FORWARD_TRIS PORTW07_TRIS//LATBbits.LATB3
#define DOOR_BACKWARD_TRIS PORTW08_TRIS //LATBbits.LATB2
#define DOOR_FORWARD_SET PORTW07_LAT
#define DOOR_BACKWARD_SET PORTW08_LAT





// Define the left motor drive port
#define LEFT_MOTOR PWM_PORTY12
#define LEFT_FORWARD_TRIS PORTY09_TRIS//LATBbits.LATB3
#define LEFT_BACKWARD_TRIS PORTY11_TRIS //LATBbits.LATB2
#define LEFT_FORWARD_SET PORTY09_LAT
#define LEFT_BACKWARD_SET PORTY11_LAT


// Define the right motor drive port
#define RIGHT_MOTOR PWM_PORTY10
#define RIGHT_FORWARD_TRIS PORTY07_TRIS//LATBbits.LATB3
#define RIGHT_BACKWARD_TRIS PORTY05_TRIS //LATBbits.LATB2
#define RIGHT_FORWARD_SET PORTY07_LAT
#define RIGHT_BACKWARD_SET PORTY05_LAT

#define TRACK_WIRE1_PIN AD_PORTW4
#define TRACK_WIRE2_PIN AD_PORTW3//LATBbits.LATB3

#define FRONTRIGHTBUMP_V5 PORTV05_BIT
#define FRONTLEFTBUMP_V6 PORTV06_BIT
#define TOPRIGHTBUMP_V7 PORTV07_BIT
#define TOPLEFTBUMP_V8 PORTV08_BIT

#define TOPRIGHTTAPE_X4 PORTX04_BIT
#define TOPLEFTTAPE_X6 PORTX06_BIT
#define BOTRIGHTTAPE_X3 PORTX03_BIT
#define BOTLEFTTAPE_X5 PORTX05_BIT
#define NUM_CHECKS 5


// Define the max speed
#define MAX_SPEED 100
#define BEACON_HI_THRESH 800 // ARBITRARY ACTUALLY TEST THIS SHIT
#define BEACON_LO_THRESH 750 // ARBITRARY ACTUALLY TEST THIS SHIT






void DriveBase_Init(void);

char LeftMotorSpeed(char newSpeed);

char RightMotorSpeed(char newSpeed);

char TurnRight(char newSpeed);

char TurnLeft(char newSpeed);

char Forward(char newSpeed);

char Reverse(char newSpeed);
char Brush_MtrSpeed(char newSpeed);
char Door_MtrSpeed(char newSpeed);

char Stop(void);

uint8_t ReadTopRightBumper(void);

uint8_t ReadTopLeftBumper(void);

uint8_t ReadBotRightBumper(void);

uint8_t ReadBotLeftBumper(void);

uint8_t ReadTopRightTape(void);

uint8_t ReadTopLeftTape(void);

uint8_t ReadBotRightTape(void);

uint8_t ReadBotLeftTape(void);

uint8_t ReadTapeSensors(void);

uint8_t ReadTopTrack(void);

uint8_t ReadBotTrack(void);

uint8_t BorderDetection(void);


//uint8_t Trackwire_Detection(void);

uint8_t DoorDetection(void);

#endif
