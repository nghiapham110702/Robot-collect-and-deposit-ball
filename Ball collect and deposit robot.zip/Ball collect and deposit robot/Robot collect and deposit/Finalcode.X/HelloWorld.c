#include "xc.h"
#include <stdio.h>
#include <BOARD.h>
#include "AD.h"
#include "RC_Servo.h"
#include "pwm.h"
#include "IO_Ports.h"
#include "DriveBase.h"
#include "EventChecker.h"
//#include "SimpleService.h"
#define FRONTRIGHTBUMP 1
#define FRONTLEFTBUMP 2


#define DELAY(x)    for (wait = 0; wait <= x; wait++) {asm("nop");}
#define A_BIT       18300
#define A_LOT       183000
#define MOTOR_TIME (A_LOT <<3)
#define YET_A_BIT_LONGER (A_BIT_MORE<<2)

int main(void) {
    int wait;
    
    DriveBase_Init();
    printf("\r\n Running Y-Direction base motor test!: Forward and Back \r\n");
  
    while(1){
        switch (ReadBumper()) {

        case FRONTRIGHTBUMP: // Battery Voltage live output
            printf("\r\n Running Y-Direction base motor test!: Forward and Back \r\n");
            Forward(100);
            DELAY(MOTOR_TIME);
            Forward(80);
            DELAY(MOTOR_TIME);
            Forward(60);
            DELAY(MOTOR_TIME);
            Forward(40);
            DELAY(MOTOR_TIME);
            Forward(20);
            DELAY(MOTOR_TIME);
            Stop();
            DELAY(MOTOR_TIME);
            Reverse(20);
            DELAY(MOTOR_TIME);
            Reverse(40);
            DELAY(MOTOR_TIME);
            Reverse(60);
            DELAY(MOTOR_TIME);
            Reverse(80);
            DELAY(MOTOR_TIME);
            Reverse(100);
            DELAY(MOTOR_TIME);
            Stop();
           
            break;

        case FRONTLEFTBUMP: // Light Sensor live output
            printf("\r\n Running X-Direction base motor test!: Right and Left \r\n");
            TurnRight(100);
            DELAY(MOTOR_TIME);
            TurnRight(80);
            DELAY(MOTOR_TIME);
            TurnRight(60);
            DELAY(MOTOR_TIME);
            TurnRight(40);
            DELAY(MOTOR_TIME);
            TurnRight(20);
            DELAY(MOTOR_TIME);
            Stop();
            TurnLeft(20);
            DELAY(MOTOR_TIME);
            TurnLeft(40);
            DELAY(MOTOR_TIME);
            TurnLeft(60);
            DELAY(MOTOR_TIME);
            TurnLeft(80);
            DELAY(MOTOR_TIME);
            TurnLeft(100);
            DELAY(MOTOR_TIME);
            Stop();
            printf("\r\n X-Direction Motor Test has ended!\r\n");
            
            break;

       
        // Left motor progression
        // right motor progression


    }
    while (1);
  
//        if (ReadBumper() ){
//            printf("\r\n Running Y-Direction base motor test!: Forward and Back \r\n");
//            Forward(100);
//            DELAY(MOTOR_TIME);
//            Forward(80);
//            DELAY(MOTOR_TIME);
//            Forward(60);
//            DELAY(MOTOR_TIME);
//            Forward(40);
//            DELAY(MOTOR_TIME);
//            Forward(20);
//            DELAY(MOTOR_TIME);
//            Stop();
//            DELAY(MOTOR_TIME);
//            Reverse(20);
//            DELAY(MOTOR_TIME);
//            Reverse(40);
//            DELAY(MOTOR_TIME);
//            Reverse(60);
//            DELAY(MOTOR_TIME);
//            Reverse(80);
//            DELAY(MOTOR_TIME);
//            Reverse(100);
//            DELAY(MOTOR_TIME);
//            Stop();
//            
//            printf("\r\n Y-Direction Motor Test has ended!\r\n");
//        }
//        if (ReadTopLeftBumper()){
//            printf("\r\n Running X-Direction base motor test!: Right and Left \r\n");
//            TurnRight(100);
//            DELAY(MOTOR_TIME);
//            TurnRight(80);
//            DELAY(MOTOR_TIME);
//            TurnRight(60);
//            DELAY(MOTOR_TIME);
//            TurnRight(40);
//            DELAY(MOTOR_TIME);
//            TurnRight(20);
//            DELAY(MOTOR_TIME);
//            Stop();
//            TurnLeft(20);
//            DELAY(MOTOR_TIME);
//            TurnLeft(40);
//            DELAY(MOTOR_TIME);
//            TurnLeft(60);
//            DELAY(MOTOR_TIME);
//            TurnLeft(80);
//            DELAY(MOTOR_TIME);
//            TurnLeft(100);
//            DELAY(MOTOR_TIME);
//            Stop();
//            printf("\r\n X-Direction Motor Test has ended!\r\n");
//        }
//        
//        
//        
//        else{
//            Stop();
//   
//        }
         
        
    }
    return 0;

}
