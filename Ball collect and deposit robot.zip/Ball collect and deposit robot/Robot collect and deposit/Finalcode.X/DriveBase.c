#include <stdio.h>
#include <BOARD.h>
#include <serial.h>

#include "AD.h"
#include "ES_Configure.h"
#include "ES_Events.h"
#include "pwm.h"
#include "IO_Ports.h"
#include "RC_Servo.h"
#include "xc.h"
#include "DriveBase.h"
#include "LED.h"
#include "EventChecker.h"





#define TRACKWIRE_HIGH 1
#define TRACKWIRE_LOW 0
//#define MOTOR_TEST
//#define TRACKWIRE_SENSOR_TEST
unsigned int tape_status = TRACKWIRE_LOW;

unsigned int direction = 0;


void DriveBase_Init(void){
    
    //BOARD_Init();
    AD_Init();
    PWM_Init();
   // RC_Init();
    //LED_Init();
    PWM_SetFrequency(1000);
    
    // brush motor pwm
    
   
    PWM_AddPins(BRUSH_MOTOR_PWM);
    
    
    PWM_AddPins(LEFT_MOTOR);
    PWM_AddPins(RIGHT_MOTOR);
    PWM_AddPins(DOOR_MOTOR_PWM);
    
    PORTY12_TRIS = 0;
    LEFT_FORWARD_TRIS = 0;
    LEFT_BACKWARD_TRIS = 0;
    LEFT_FORWARD_SET = 0;
    LEFT_BACKWARD_SET = ~LEFT_FORWARD_SET;
    
    
    
    PORTZ06_TRIS = 0;
    BRUSH_FORWARD_TRIS = 0;
    BRUSH_BACKWARD_TRIS = 0;
    BRUSH_FORWARD_SET = 0;
    BRUSH_BACKWARD_SET = ~BRUSH_FORWARD_SET;
    
    PORTY10_TRIS = 0;
    RIGHT_FORWARD_TRIS = 0;
    RIGHT_BACKWARD_TRIS = 0;
    RIGHT_FORWARD_SET = 0;
    RIGHT_BACKWARD_SET = ~RIGHT_FORWARD_SET;
    
    
    PORTY04_TRIS = 0;
    DOOR_FORWARD_TRIS = 0;
    DOOR_BACKWARD_TRIS = 0;
    DOOR_FORWARD_SET = 0;
    DOOR_BACKWARD_SET = ~DOOR_FORWARD_SET;
    // Trackwire 1
    //AD_AddPins(TRACK_WIRE1_PIN);
    PORTZ05_TRIS = 0;
    PORTZ05_BIT = 1;
    //trackwire2
    //AD_AddPins(TRACK_WIRE2_PIN);
    PORTZ03_TRIS = 0;
    PORTZ03_BIT = 1;
     // Setup
    
    
    
    //AD_AddPins(TOPRIGHTBUMP_V3);
    PORTZ07_TRIS = 0;
    PORTZ07_LAT = 1;
    
    // forbumber sensor2
    //AD_AddPins(TOPLEFTBUMP_V4);
//    PORTZ08_TRIS = 0;
//    PORTZ08_LAT = 1;
//    
   
    //AD_AddPins(BOTRIGHTBUMP_V5);
    //AD_AddPins(BOTLEFTBUMP_V6);
    AD_AddPins(AD_PORTW3);
    
    //tape sensors
    PORTX03_TRIS = 1;
    PORTX04_TRIS = 1;
    PORTX05_TRIS = 1;
    PORTX06_TRIS = 1;
    // bumper
    PORTV05_TRIS = 1;
    PORTV06_TRIS = 1;
    PORTV07_TRIS = 1;
    PORTV08_TRIS = 1;
    
    
    
 
  

    
    //
    //Set the enable pins for all motors high 
    
   // IO_PortsSetPortBits(PORTX, RIGHT_ENABLE);
}

char Brush_MtrSpeed(char newSpeed)
{
    if ((newSpeed < -100) || (newSpeed > 100)) {
        return (ERROR);
    }
    newSpeed = -newSpeed;
  
    if (newSpeed < 0) {
        BRUSH_FORWARD_SET = 0;
        newSpeed = newSpeed * (-1); // set speed to a positive value
        
    } else {
        BRUSH_FORWARD_SET = 1;
    }
    BRUSH_BACKWARD_SET = ~(BRUSH_FORWARD_SET);
    PWM_SetDutyCycle(BRUSH_MOTOR_PWM, newSpeed * (MAX_PWM / MAX_SPEED));
    
    return (SUCCESS);
}
char Door_MtrSpeed(char newSpeed){
     if ((newSpeed < -100) || (newSpeed > 100)) {
        return (ERROR);
    }
    newSpeed = -newSpeed;
  
    if (newSpeed < 0) {
        DOOR_FORWARD_SET = 0;
        newSpeed = newSpeed * (-1); // set speed to a positive value
        
    } else {
        DOOR_FORWARD_SET = 1;
    }
    DOOR_BACKWARD_SET = ~(DOOR_FORWARD_SET);
    PWM_SetDutyCycle(DOOR_MOTOR_PWM, newSpeed * (MAX_PWM / MAX_SPEED));
    
    return (SUCCESS);
    
}

char LeftMotorSpeed(char newSpeed){
    if ((newSpeed < -100) || (newSpeed > 100)) {
        return (ERROR);
    }
    newSpeed = -newSpeed;
  
    if (newSpeed < 0) {
        LEFT_FORWARD_SET = 0;
        newSpeed = newSpeed * (-1); // set speed to a positive value
        
    } else {
        LEFT_FORWARD_SET = 1;
    }
    LEFT_BACKWARD_SET = ~(LEFT_FORWARD_SET);
    PWM_SetDutyCycle(LEFT_MOTOR, newSpeed * (MAX_PWM / MAX_SPEED));
    
    return (SUCCESS);
    
}

char RightMotorSpeed(char newSpeed){
   if ((newSpeed < -100) || (newSpeed > 100)) {
        return (ERROR);
    }
    newSpeed = -newSpeed;
  
    if (newSpeed < 0) {
        RIGHT_FORWARD_SET = 0;
        newSpeed = newSpeed * (-1); // set speed to a positive value
        
    } else {
        RIGHT_FORWARD_SET = 1;
    }
    RIGHT_BACKWARD_SET = ~(RIGHT_FORWARD_SET);
    PWM_SetDutyCycle(RIGHT_MOTOR, newSpeed * (MAX_PWM / MAX_SPEED));
    
    return (SUCCESS);
}

char TurnRight(char newSpeed){
    if (newSpeed > 100 || newSpeed < 0){
        return (ERROR);
    }
    RightMotorSpeed(-newSpeed);
    LeftMotorSpeed(newSpeed);
    return (SUCCESS);
}

char TurnLeft(char newSpeed){
    if (newSpeed > 100 || newSpeed < 0){
        return (ERROR);
    }
    RightMotorSpeed(newSpeed);
    LeftMotorSpeed(-newSpeed);
    return (SUCCESS);
}

char Forward(char newSpeed){
    if (newSpeed > 100 || newSpeed < 0){
        return (ERROR);
    }
    RightMotorSpeed(newSpeed);
    LeftMotorSpeed(newSpeed-2);
    return (SUCCESS);
}

char Reverse(char newSpeed){
    if (newSpeed > 100 || newSpeed < 0){
        return (ERROR);
    }
    RightMotorSpeed(-newSpeed);
    LeftMotorSpeed(-newSpeed + 2);
    return (SUCCESS);
}
char Stop(void){
    //
    printf("\r\n Stop has been called\r\n");
    RightMotorSpeed(0);
    LeftMotorSpeed(0);
    return (SUCCESS);
}
//uint8_t Trackwire_Detection(void){
//    static ES_EventTyp_t lastEvent = TRACKWIRE_UNDETECTED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTZ04_TRIS = 0;
//    PORTZ04_BIT = 1;
//    unsigned int rawVal = AD_ReadADPin(TRACKWIRE_PIN);
//    
//    //printf("The ADC value being read is %d. \r\n", rawVal);
//
//
//    if (rawVal > TRACKWIRE_HI_THRESH){
//        curEvent = TRACKWIRE_DETECTED;
//        
//    } else if (rawVal < TRACKWIRE_LO_THRESH){
//        curEvent = TRACKWIRE_UNDETECTED;
//        printf("Ihate this class, soooooooooooooooo much");
//    } else{
//        curEvent = lastEvent;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostGenericService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
#ifdef MOTOR_TEST
int main(void){
    printf("Running motor test \r\n");
    DriveBase_Init();
    while (1) {
        Brush_MtrSpeed(-100);
        LeftMotorSpeed(-100);
        RightMotorSpeed(-100);
        //Door_MtrSpeed(100);
        //printf("hi");
        
        
       
    }
    
    return 0;
    
    
}
#endif
#ifdef TRACKWIRE_SENSOR_TEST
int main(void) {
    
    printf("Starting up test harness for TRACKWIRE_SENSOR_TEST detection. \r\n");
    printf("Warning, all test harnesses uses the same pin, which is V3. \r\n");
    
    // Initialization functions
    BOARD_Init(); // Board
    AD_Init(); // AD Pins
    
    // Setup
    AD_AddPins(TRACKWIRE_PIN);
    PORTZ04_TRIS = 0;
    PORTZ04_BIT = 1;
    
    // Main event loop
    while (1) {
        // Read the value from the ADC pin if needed
        if (AD_IsNewDataReady() == TRUE) {
//            for(int x = 0; x<150000; x++){
//                asm("nop");
//            }
            unsigned int trackwire_sensor_reading = AD_ReadADPin(TRACKWIRE_PIN);
            unsigned int new_status;
            
            // Compare readings and trigger event if the value is different for hysteresis
            if (trackwire_sensor_reading >= TRACKWIRE_HI_THRESH) {
                new_status = TRACKWIRE_HIGH;
            } else {
                new_status = TRACKWIRE_LOW;
            }
            
            // Print out message if status is different
            if (new_status != tape_status) {
                if (new_status == TRACKWIRE_HIGH) {
                    printf("Trackwire sensor detected high. \r\n");
                } else {
                    printf("Trackwire sensor detected low. \r\n");
                }
            }
            
            // Update previous status to the new status
            tape_status = new_status;
            
            // Test Display (remove when you have successfully gotten a pin reading)
            //printf("The tape sensor reading from the ADC is %d. \r\n", trackwire_sensor_reading);
        }
    }
    
    return 0;
}
#endif





