

#include "xc.h"
#include <roach.h>
#include "BOARD.h"
#include <stdio.h>

#define DELAY(x) for (wait=0; wait<= x; wait++) {asm("nop");}
#define A_BIT       18300
#define A_BIT_MORE  36600
#define A_LOT 183000
#define MOTOR_TIME (A_LOT <<2)
#define YET_A_BIT_LONGER (A_BIT_MORE<<2)


#define FRONT_LEFT_BUMPER_PRESSED 1
#define FRONT_RIGHT_BUMPER_PRESSED 2
#define REAR_LEFT_BUMPER_PRESSED 4
#define REAR_RIGHT_BUMPER_PRESSED 8

#define LIGHTTHRESH 500
void FlashLEDBar(uint8_t numtimes)
{
    unsigned int wait, i;
    Roach_LEDSSet(0);
    for (i = 0; i < numtimes; i++) {
        Roach_LEDSSet(0xFFF);
        DELAY(YET_A_BIT_LONGER);
        Roach_LEDSSet(0x000);
        DELAY(YET_A_BIT_LONGER);
    }
}

int main(void) {
    BOARD_Init();
    Roach_Init();
    
    unsigned int wait;
    unsigned int currentLight;
    unsigned int batterylevel;
    printf("Running our Test Harness!\n");
    printf("Running LED test, flashing 10 times \n");
    
    // Runs the flash LED
    FlashLEDBar(10);
    while (1){
        switch(Roach_ReadBumpers()){
            case FRONT_RIGHT_BUMPER_PRESSED:
                printf("Front right bumper pressed! \n");
                printf("Running Right Motor Test! \n");
                Roach_RightMtrSpeed(100);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(80);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(60);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(40);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(20);
                DELAY(MOTOR_TIME);
                printf("Motor Stopped! \n");
                Roach_RightMtrSpeed(0);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(-20);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(-40);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(-60);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(-80);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(-100);
                DELAY(MOTOR_TIME);
                Roach_RightMtrSpeed(0);
                printf("Right motor test is over!");
                break;
            case FRONT_LEFT_BUMPER_PRESSED:
                printf("Front left bumper pressed! \n");
                printf("Running Left Motor Test! \n");
                Roach_LeftMtrSpeed(100);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(80);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(60);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(40);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(20);
                DELAY(MOTOR_TIME);
                printf("Motor Stopped! \n");
                Roach_LeftMtrSpeed(0);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(-20);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(-40);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(-60);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(-80);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(-100);
                DELAY(MOTOR_TIME);
                Roach_LeftMtrSpeed(0);
                printf("Left motor test is over!");
                break;
            case REAR_RIGHT_BUMPER_PRESSED:
                printf("Rear right bumper pressed!\n");
                printf("Running Light Test!");
                
                for (int i = 0; i < 9; i ++){
                    currentLight = Roach_LightLevel();
                    if (currentLight > LIGHTTHRESH){
                        printf("  OMG!. IT?S TOO DARK, I?M TOO SCARE");
                        printf("\r\nCurrent Light Level: %d", currentLight);
                        
                    } else if (currentLight <= LIGHTTHRESH){
                        printf (" TOO BRIGHT, IT HURT MY EYES ");
                        printf("\r\nCurrent Light Level: %d", currentLight);
                    }
                    DELAY(MOTOR_TIME);
                }
                printf("Test is over! ");
                break;
            case REAR_LEFT_BUMPER_PRESSED:
                printf("Rear left bumper pressed!\n");
                printf("Running Battery Test!");
                batterylevel = Roach_BatteryVoltage() *32;
                printf("Battery Test: %u mv ", batterylevel);
                DELAY(A_LOT);  
                printf("Battery Test is over!");
                break;
        }
    }
    
    
    return 0;
}
