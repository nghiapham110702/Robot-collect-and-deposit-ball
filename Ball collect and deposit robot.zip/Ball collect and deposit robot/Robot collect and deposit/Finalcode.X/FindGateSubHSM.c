/*
 * File: TemplateSubHSM.c
 * Author: J. Edward Carryer
 * Modified: Gabriel H Elkaim
 *
 * Template file to set up a Heirarchical State Machine to work with the Events and
 * Services Framework (ES_Framework) on the Uno32 for the CMPE-118/L class. Note that
 * this file will need to be modified to fit your exact needs, and most of the names
 * will have to be changed to match your code.
 *
 * There is for a substate machine. Make sure it has a unique name
 *
 * This is provided as an example and a good place to start.
 *
 * History
 * When           Who     What/Why
 * -------------- ---     --------
 * 09/13/13 15:17 ghe      added tattletail functionality and recursive calls
 * 01/15/12 11:12 jec      revisions for Gen2 framework
 * 11/07/11 11:26 jec      made the queue static
 * 10/30/11 17:59 jec      fixed references to CurrentEvent in RunTemplateSM()
 * 10/23/11 18:20 jec      began conversion from SMTemplate.c (02/20/07 rev)
 */


/*******************************************************************************
 * MODULE #INCLUDE                                                             *
 ******************************************************************************/

//#include "ES_Configure.h"
//#include "ES_Framework.h"
//#include "BOARD.h"
//#include "mainHSM.h"
//#include "DriveBase.h"
//#include "FindGateSubHSM.h"
//#include "AligningSubHSM.h"
//#include "DodgingSubHSM.h"
//#include "EventChecker.h"
//#include <stdio.h>
//#include "AD.h"

/*******************************************************************************
 * MODULE #DEFINES                                                             *
 ******************************************************************************/


/*
 * File: TemplateSubHSM.c
 * Author: J. Edward Carryer
 * Modified: Gabriel H Elkaim
 *
 * Template file to set up a Heirarchical State Machine to work with the Events and
 * Services Framework (ES_Framework) on the Uno32 for the CMPE-118/L class. Note that
 * this file will need to be modified to fit your exact needs, and most of the names
 * will have to be changed to match your code.
 *
 * There is for a substate machine. Make sure it has a unique name
 *
 * This is provided as an example and a good place to start.
 *
 * History
 * When           Who     What/Why
 * -------------- ---     --------
 * 09/13/13 15:17 ghe      added tattletail functionality and recursive calls
 * 01/15/12 11:12 jec      revisions for Gen2 framework
 * 11/07/11 11:26 jec      made the queue static
 * 10/30/11 17:59 jec      fixed references to CurrentEvent in RunTemplateSM()
 * 10/23/11 18:20 jec      began conversion from SMTemplate.c (02/20/07 rev)
 */


/*******************************************************************************
 * MODULE #INCLUDE                                                             *
 ******************************************************************************/

#include "ES_Configure.h"
#include "ES_Framework.h"
#include "BOARD.h"
#include "mainHSM.h"
#include "DriveBase.h"
#include "FindGateSubHSM.h"
#include "AligningSubHSM.h"
#include "DodgingSubHSM.h"
#include "EventChecker.h"
#include <stdio.h>
#include "AD.h"
#include "LED.h"

/*******************************************************************************
 * MODULE #DEFINES                                                             *
 ******************************************************************************/
typedef enum {
    InitPSubState,
    Looking,
    LookingAfterWall,
    PivotLeft,
    PivotRight,
    TurningLeft,
    StopLeftTurn,
    OpeningGate,
    ClosingGate,
    BackingAway,
    TurningAway,
    AligningToWall,
    RealigningToWall,
    DodgingLeft,
    DodgingRight,
    BumpedWall,
    MovingForward,
    DoorStuck,
    StuckOnCorner,
    PivotRightFix,
    PivotLeftFix,
    SqueezeByObjectLeft,
    ExitSub
} FindGateSubHSMState_t;

static const char *StateNames[] = {
    "InitPSubState",
    "Looking",
    "LookingAfterWall",
    "PivotLeft",
    "PivotRight",
    "TurningLeft",
    "StopLeftTurn",
    "OpeningGate",
    "ClosingGate",
    "BackingAway",
    "TurningAway",
    "AligningToWall",
    "RealigningToWall",
    "DodgingLeft",
    "DodgingRight",
    "BumpedWall",
    "MovingForward",
    "DoorStuck",
    "StuckOnCorner",
    "PivotRightFix",
    "PivotLeftFix",
    "SqueezeByObjectLeft",
    "ExitSub"
};



/*******************************************************************************
 * PRIVATE FUNCTION PROTOTYPES                                                 *
 ******************************************************************************/
/* Prototypes for private functions for this machine. They should be functions
   relevant to the behavior of this state machine */

/*******************************************************************************
 * PRIVATE MODULE VARIABLES                                                            *
 ******************************************************************************/
/* You will need MyPriority and the state variable; you may need others as well.
 * The type of state variable should match that of enum in header file. */

static FindGateSubHSMState_t CurrentState = InitPSubState; // <- change name to match ENUM
static uint8_t MyPriority;

uint8_t trackwireFlag;
uint16_t turnMore;
uint8_t bumperParam;
uint8_t ignoringTape;
uint8_t depositCount;

/*******************************************************************************
 * PUBLIC FUNCTIONS                                                            *
 ******************************************************************************/

/**
 * @Function InitTemplateSubHSM(uint8_t Priority)
 * @param Priority - internal variable to track which event queue to use
 * @return TRUE or FALSE
 * @brief This will get called by the framework at the beginning of the code
 *        execution. It will post an ES_INIT event to the appropriate event
 *        queue, which will be handled inside RunTemplateFSM function. Remember
 *        to rename this to something appropriate.
 *        Returns TRUE if successful, FALSE otherwise
 * @author J. Edward Carryer, 2011.10.23 19:25 */
uint8_t InitFindGateSubHSM(void) {
    ES_Event returnEvent;
    
    //LED_Init();
    //LED_AddBanks(1);
    //LED_SetBank(1, 0b0000);
    turnMore = 0;
    bumperParam = 0;
    ignoringTape = 0;
    depositCount = 0;
    CurrentState = InitPSubState;
    returnEvent = RunFindGateSubHSM(INIT_EVENT);
    if (returnEvent.EventType == ES_NO_EVENT) {
        return TRUE;
    }
    return FALSE;
}

/**
 * @Function RunTemplateSubHSM(ES_Event ThisEvent)
 * @param ThisEvent - the event (type and param) to be responded.
 * @return Event - return event (type and param), in general should be ES_NO_EVENT
 * @brief This function is where you implement the whole of the heirarchical state
 *        machine, as this is called any time a new event is passed to the event
 *        queue. This function will be called recursively to implement the correct
 *        order for a state transition to be: exit current state -> enter next state
 *        using the ES_EXIT and ES_ENTRY events.
 * @note Remember to rename to something appropriate.
 *       The lower level state machines are run first, to see if the event is dealt
 *       with there rather than at the current level. ES_EXIT and ES_ENTRY events are
 *       not consumed as these need to pass pack to the higher level state machine.
 * @author Nghia Pham, Zac Kaner, 2024.06.02  19:25
 * @author Nghia Pham, Zac Kaner, 2024.06.02 19:25 */
ES_Event RunFindGateSubHSM(ES_Event ThisEvent) {
    uint8_t makeTransition = FALSE; // use to flag transition
    FindGateSubHSMState_t nextState; // <- change type to correct enum

    ES_Tattle(); // trace call stack

    switch (CurrentState) {
        case InitPSubState: // If current state is initial Psedudo State
            if (ThisEvent.EventType == ES_INIT)// only respond to ES_Init
            {
                // this is where you would put any actions associated with the
                // transition from the initial pseudo-state into the actual
                // initial state

                // now put the machine into the actual initial state

                nextState = Looking;
                makeTransition = TRUE;
                ThisEvent.EventType = ES_NO_EVENT;
            }
            break;

        case Looking: // in the first state, replace this with correct names
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    turnMore = 0;
                    bumperParam = 0;
                    LeftMotorSpeed(100);
                    RightMotorSpeed(99);
                    break;
                case BUMPERTOGGLED:
                    if(ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        nextState = DodgingLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else {
                        if (bumperParam < ThisEvent.EventParam){
                            bumperParam = ThisEvent.EventParam;
                        }
                        ES_Timer_InitTimer(11, 50); // waiting for other bumper events
                    }
                        
                    break;
                        
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED) {
                        nextState = PivotLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED) {
                        nextState = PivotRight;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case ES_TIMEOUT:
                     if (ThisEvent.EventParam == 14){
                        turnMore = 0;
                    } else if (ThisEvent.EventParam == 11){
                        if (bumperParam > BOTH_FRONT_BUMPERS_PRESSED){
                            nextState = DodgingLeft;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        } else {
                            nextState = BumpedWall;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        }
                        bumperParam = 0;
                    }
                    break;

                default: // all unhandled events pass the event back up to the next level
                    break;
            }
            break;
        case LookingAfterWall:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    LeftMotorSpeed(100);
                    RightMotorSpeed(70);
                    break;
                case BUMPERTOGGLED:
                    if (ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        nextState = DodgingLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                        
                    } else {
                        nextState = BumpedWall;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                        
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED) {
                        nextState = PivotLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED) {
                        nextState = PivotRight;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case ES_TIMEOUT:
                     if (ThisEvent.EventParam == 14){
                        turnMore = 0;
                    }
                    break;

                default: // all unhandled events pass the event back up to the next level
                    break;
            }
            break;

        case DodgingLeft:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    Reverse(100);
                    ES_Timer_InitTimer(1, 300);
                    break;
                case BUMPERTOGGLED:
                    if(ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        nextState = DodgingLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else {
                        if (bumperParam < ThisEvent.EventParam){
                            bumperParam = ThisEvent.EventParam;
                        }

                        ES_Timer_InitTimer(11, 50); // waiting for other bumper events
                    }
                        
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam >= TOP_RIGHT_TAPE_TOGGLED) { // either of the top tape toggled
                        LeftMotorSpeed(100);
                        RightMotorSpeed(60);
                        ES_Timer_InitTimer(4, 500);
                    } else if ((ThisEvent.EventParam & 0b0010) >> 1){ //if bot left tape gets toggled
                        ES_Timer_StopTimer(1);
                        ES_Timer_StopTimer(2);
                        nextState = SqueezeByObjectLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                        
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnLeft(100);
                        ES_Timer_InitTimer(2, NINETYDEGTURN+turnMore);
                    } else if (ThisEvent.EventParam == 2){
                        ES_Timer_InitTimer(14, 500);
                        turnMore = 400;
                        nextState = DodgingRight;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 4){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 14){
                        turnMore = 0;
                    } else if (ThisEvent.EventParam == 11){
                        if (bumperParam > BOTH_FRONT_BUMPERS_PRESSED){
                            nextState = DodgingLeft;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        } else {
                            nextState = BumpedWall;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        }
                        bumperParam = 0;
                    }
                    break;
            }
            break;
            
        case SqueezeByObjectLeft:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    Forward(90);
                    ES_Timer_InitTimer(1, 1500);
                    break;
                case BUMPERTOGGLED:
                    ES_Timer_StopTimer(1);
                    if (ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        ES_Timer_StopTimer(5);
                        LeftMotorSpeed(-100);
                        RightMotorSpeed(-60);
                    } else {
                        ES_Timer_InitTimer(5, 100);
                    }
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam < TOP_RIGHT_TAPE_TOGGLED){ // bottom tape toggled
                        nextState = SqueezeByObjectLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnRight(100);
                        ES_Timer_InitTimer(3, 200);
                    } else if (ThisEvent.EventParam == 2){
                        LeftMotorSpeed(0);
                        RightMotorSpeed(-100);
                        ES_Timer_InitTimer(3, 800);
                    } else if (ThisEvent.EventParam == 3){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 5){
                        Reverse(100);
                        ES_Timer_InitTimer(2, 100);
                    }
                    break;
            }
            break;
            
        case DodgingRight:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    Forward(100);
                    ES_Timer_InitTimer(1, DODGINGFORWARD);
                    
                    break;
                case BUMPERTOGGLED:
                    if(ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        nextState = DodgingLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else {
                        if (bumperParam < ThisEvent.EventParam){
                            bumperParam = ThisEvent.EventParam;
                        }

                        ES_Timer_InitTimer(11, 50); // waiting for other bumper events
                    }
                    break;
                        
                        
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED) {
                        nextState = PivotLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED) {
                        nextState = PivotRight;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnRight(100);
                        ES_Timer_InitTimer(2, NINETYDEGTURN);
                    } else if (ThisEvent.EventParam == 2){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 14){
                        turnMore = 0;
                    } else if (ThisEvent.EventParam == 11){
                        if (bumperParam > BOTH_FRONT_BUMPERS_PRESSED){
                            nextState = DodgingLeft;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        } else {
                            nextState = BumpedWall;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        }
                        bumperParam = 0;
                    }
                        
                    break;
            }
            break;
        
        case BumpedWall:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    LeftMotorSpeed(0);
                    RightMotorSpeed(-100);
                    ES_Timer_InitTimer(1, 200);
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED) {
                        nextState = PivotLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED) {
                        nextState = PivotRight;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case BUMPERTOGGLED:
                    if (ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        Reverse(100);
                        ES_Timer_InitTimer(2, 300);
                    } else {
                        nextState = BumpedWall;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        LeftMotorSpeed(95);
                        RightMotorSpeed(100);
                    } else if (ThisEvent.EventParam == 2){
                        TurnRight(100);
                        ES_Timer_InitTimer(3, NINETYDEGTURN);
                            
                    } else if (ThisEvent.EventParam == 3){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                        
                    break;
            }
            break;

        case PivotLeft:
            switch (ThisEvent.EventType) {
                case ES_ENTRY: // move back to untoggle tape
                    LeftMotorSpeed(-100);
                    RightMotorSpeed(0);
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_UNTOGGLED) { // move forward to retoggle tape
                        LeftMotorSpeed(100);
                        RightMotorSpeed(60);
                        ES_Timer_InitTimer(3, 250);
                    }
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED) { // move back to untoggle tape
                        LeftMotorSpeed(-100);
                        ES_Timer_StopTimer(3);
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED | ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        ES_Timer_StopTimer(3);
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED + BOT_LEFT_TAPE_TOGGLED){
                        ES_Timer_StopTimer(3);
                        nextState = PivotLeftFix;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;    
                case BUMPERTOGGLED:
                    Reverse(100);
                    ES_Timer_InitTimer(1, 500);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnLeft(100);
                        ES_Timer_InitTimer(2, NINETYDEGTURN-200);
                    } else if (ThisEvent.EventParam == 2){
                        ES_Timer_StopTimer(3);
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 3){
                        nextState = PivotLeftFix;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                default:
                    break;
            }
            break;
        case PivotRight:
            switch (ThisEvent.EventType) {
                case ES_ENTRY: // move back to untoggle tape
                    RightMotorSpeed(-100);
                    LeftMotorSpeed(0);
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam == TOP_RIGHT_TAPE_UNTOGGLED) { // move forward to retoggle tape
                        RightMotorSpeed(100);
                        LeftMotorSpeed(60);
                        ES_Timer_InitTimer(3, 250);
                    }
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED) { // move back to untoggle tape
                        RightMotorSpeed(-100);
                        ES_Timer_StopTimer(3);
                    } else if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED | ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED) {
                        ES_Timer_StopTimer(3);
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED + BOT_RIGHT_TAPE_TOGGLED){
                        ES_Timer_StopTimer(3);
                        nextState = PivotRightFix;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case BUMPERTOGGLED:
                    Reverse(100);
                    ES_Timer_InitTimer(1, 500);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnRight(100);
                        ES_Timer_InitTimer(2, NINETYDEGTURN-200);
                    } else if (ThisEvent.EventParam == 2){
                        ES_Timer_StopTimer(3);
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == 3){
                        nextState = PivotRightFix;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                default:
                    break;
            }
            break;
            
        case PivotRightFix:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    RightMotorSpeed(-100);
                    LeftMotorSpeed(-60);
                    ES_Timer_InitTimer(6, 1000);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 6){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
            }
            break;
            
            case PivotLeftFix:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    LeftMotorSpeed(-100);
                    RightMotorSpeed(-60);
                    ES_Timer_InitTimer(6, 1000);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 6){
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
            }
            break;
            
        case TurningLeft:
            switch (ThisEvent.EventType) {
                case ES_ENTRY: // turn left
                    RightMotorSpeed(80);
                    LeftMotorSpeed(-70);
                    ES_Timer_InitTimer(6, IGNOREEVENTS); // ignore events for this amount of time
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 6){
                        nextState = StopLeftTurn;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                        
                    break;
            }
            break;
            
        case StopLeftTurn:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    RightMotorSpeed(60);
                    LeftMotorSpeed(-50);
                    ES_Timer_InitTimer(11, 800);
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam == TOP_RIGHT_TAPE_UNTOGGLED | ThisEvent.EventParam == TOP_RIGHT_TAPE_UNTOGGLED + BOT_RIGHT_TAPE_TOGGLED) {
                        ES_Timer_StopTimer(11);
                        nextState = MovingForward;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                        //                        Reverse(100);
                        //                        ES_Timer_InitTimer(1, 500);
                    }
                    break;
          
                case ES_TIMEOUT: // randomly spinning
                    if (ThisEvent.EventParam == 11){
                        nextState = DoorStuck;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
            }
            break;
            
        case DoorStuck:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    LeftMotorSpeed(-55);
                    RightMotorSpeed(-100);
                    ES_Timer_InitTimer(1, 700);
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam < 3){ // back tape sensors
                        nextState = StuckOnCorner;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } 
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam < 3){ // back tape sensors
                        nextState = StuckOnCorner;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } 
                    break;
                case ES_TIMEOUT:
                    nextState = Looking;
                    makeTransition = TRUE;
                    ThisEvent.EventType = ES_NO_EVENT;
                    break;
            }
            break;
            
        case StuckOnCorner:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    LeftMotorSpeed(100);
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam >= TOP_LEFT_TAPE_TOGGLED){
                        if (ignoringTape == 1){
                            break;
                        } else {
                            ignoringTape = 1;
                            LeftMotorSpeed(-90);
                            RightMotorSpeed(-100);
                            ES_Timer_InitTimer(1, 1200);
                        }
                    }
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam >= TOP_LEFT_TAPE_TOGGLED){
                        if (ignoringTape == 1){
                            break;
                        } else {
                            ignoringTape = 1;
                            LeftMotorSpeed(-90);
                            RightMotorSpeed(-100);
                            ES_Timer_InitTimer(1, 1200);
                        }
                    }
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        TurnRight(100);
                        ES_Timer_InitTimer(2, 900);
                    } else if (ThisEvent.EventParam == 2){
                        ignoringTape = 0;
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
            }
            break;

        case MovingForward:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    bumperParam = 0;
                    RightMotorSpeed(95);
                    LeftMotorSpeed(100);
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED | ThisEvent.EventParam == TOP_RIGHT_TAPE_TOGGLED + BOT_RIGHT_TAPE_TOGGLED) {
                        LeftMotorSpeed(0);
                    } else if (ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED | ThisEvent.EventParam == BOTH_TOP_TAPE_TOGGLED + BOT_RIGHT_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else if (ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED | ThisEvent.EventParam == TOP_LEFT_TAPE_TOGGLED + BOT_RIGHT_TAPE_TOGGLED) {
                        nextState = TurningLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam == TOP_RIGHT_TAPE_UNTOGGLED | ThisEvent.EventParam == TOP_RIGHT_TAPE_UNTOGGLED + BOT_RIGHT_TAPE_TOGGLED) {
                        RightMotorSpeed(95);
                        LeftMotorSpeed(100);
                    }
                    break;
                case BUMPERTOGGLED:
                    if(ThisEvent.EventParam > BOTH_FRONT_BUMPERS_PRESSED){
                        nextState = DodgingLeft;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    } else {
                        ES_Timer_InitTimer(1, 50);
                        if (bumperParam < ThisEvent.EventParam){
                            bumperParam = ThisEvent.EventParam;
                        }
                    }
                    break;
                        
                    
                    
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        if (bumperParam <= BOTH_FRONT_BUMPERS_PRESSED) { 
                            if (bumperParam == FRONT_LEFT_BUMPER_PRESSED) {
                                LeftMotorSpeed(50);
                                RightMotorSpeed(100);
                            } else if (bumperParam == FRONT_RIGHT_BUMPER_PRESSED) {
                                LeftMotorSpeed(100);
                                RightMotorSpeed(50);
                            } else if (bumperParam == BOTH_FRONT_BUMPERS_PRESSED) {
                                LeftMotorSpeed(0);
                                RightMotorSpeed(0);
                                if (depositCount == 0){
                                    depositCount++;
                                    nextState = BackingAway;
                                    makeTransition = TRUE;
                                    ThisEvent.EventType = ES_NO_EVENT;
                                } else {
                                    depositCount++;
                                    nextState = OpeningGate;
                                    makeTransition = TRUE;
                                    ThisEvent.EventType = ES_NO_EVENT;
                                }
                                    
                            }
                            bumperParam = 0;
                        } else { // if any of the top bumpers get detected
                            nextState = DodgingLeft;
                            makeTransition = TRUE;
                            ThisEvent.EventType = ES_NO_EVENT;
                        }
                    }
                        
                    break;
             
                
                default:
                    break;
            }
            break;
        case OpeningGate:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    Door_MtrSpeed(100);
                    ES_Timer_InitTimer(1, 500);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1) {
                        Door_MtrSpeed(0);
                        Brush_MtrSpeed(-100);
                        ES_Timer_InitTimer(2, 1200); // waiting until all balls ejected
                    } else if (ThisEvent.EventParam == 2) {
                        Brush_MtrSpeed(100);
                        nextState = ClosingGate;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;


            }
            break;
        case ClosingGate:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    Door_MtrSpeed(-100);
                    ES_Timer_InitTimer(1, 400);
                    break;
                case ES_TIMEOUT:
                    Door_MtrSpeed(0);
                    nextState = BackingAway;
                    makeTransition = TRUE;
                    ThisEvent.EventType = ES_NO_EVENT;
                    break;
            }
            break;
        case BackingAway:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    RightMotorSpeed(-90);
                    LeftMotorSpeed(-80);
                    ES_Timer_InitTimer(1, 150);
                    break;
                case ES_TIMEOUT:
                    nextState = TurningAway;
                    makeTransition = TRUE;
                    ThisEvent.EventType = ES_NO_EVENT;
                    break;
            }
            break;
        case TurningAway:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    TurnLeft(90);
                    ES_Timer_InitTimer(1, PARALLELPARK);
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        Forward(80);
                        ES_Timer_InitTimer(2, 300);
                    } else if (ThisEvent.EventParam == 2){
                        nextState = AligningToWall;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
            }
            break;

        case AligningToWall:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    ES_Timer_StopTimer(4);
                    RightMotorSpeed(-100);
                    LeftMotorSpeed(-70);
                    ES_Timer_InitTimer(4, RECORRECTPARK);
                    break;
                case TAPETOGGLED:
                    if (ThisEvent.EventParam == BOT_LEFT_TAPE_TOGGLED) {
                        RightMotorSpeed(-60);
                        LeftMotorSpeed(70);
                    } else if (ThisEvent.EventParam == BOT_LEFT_TAPE_TOGGLED + BOT_RIGHT_TAPE_TOGGLED) { // both bottom tape sensors
                        ES_Timer_StopTimer(4);
                        ES_Timer_InitTimer(15, 1); // transitions to cleaning state (top level)
                        nextState = Looking;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                case TAPEUNTOGGLED:
                    if (ThisEvent.EventParam == BOT_LEFT_TAPE_UNTOGGLED) {
                        LeftMotorSpeed(-70);
                    }
                    break;
                case ES_TIMEOUT:
                    if (ThisEvent.EventParam == 1){
                        nextState = AligningToWall;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                       
                    } else if (ThisEvent.EventParam == 4){
                        nextState = RealigningToWall;
                        makeTransition = TRUE;
                        ThisEvent.EventType = ES_NO_EVENT;
                    }
                    break;
                        
            }
            break;
        case RealigningToWall:
            switch (ThisEvent.EventType) {
                case ES_ENTRY:
                    ES_Timer_InitTimer(1, 300);
                    LeftMotorSpeed(100);
                    RightMotorSpeed(80);
                    break;
                case ES_TIMEOUT:
                    nextState = AligningToWall;
                    makeTransition = TRUE;
                    ThisEvent.EventType = ES_NO_EVENT;
                    break;
            }
            break;
        case ExitSub:
            if (ThisEvent.EventType == ES_ENTRY) {
                nextState = Looking;
                makeTransition = TRUE;
                ThisEvent.EventType = ES_NO_EVENT;
            }
            break;

        default: // all unhandled states fall into here
            break;
    } // end switch on Current State

    if (makeTransition == TRUE) { // making a state transition, send EXIT and ENTRY
        // recursively call the current state with an exit event
        RunFindGateSubHSM(EXIT_EVENT); // <- rename to your own Run function
        CurrentState = nextState;
        RunFindGateSubHSM(ENTRY_EVENT); // <- rename to your own Run function
    }

    ES_Tail(); // trace call stack end
    return ThisEvent;
}


/*******************************************************************************
 * PRIVATE FUNCTIONS                                                           *
 ******************************************************************************/