/*
 * File:   TemplateEventChecker.c
 * Author: Gabriel Hugh Elkaim
 *
 * Template file to set up typical EventCheckers for the  Events and Services
 * Framework (ES_Framework) on the Uno32 for the CMPE-118/L class. Note that
 * this file will need to be modified to fit your exact needs, and most of the
 * names will have to be changed to match your code.
 *
 * This EventCheckers file will work with both FSM's and HSM's.
 *
 * Remember that EventCheckers should only return TRUE when an event has occured,
 * and that the event is a TRANSITION between two detectable differences. They
 * should also be atomic and run as fast as possible for good results.
 *
 * This file includes a test harness that will run the event detectors listed in the
 * ES_Configure file in the project, and will conditionally compile main if the macro
 * EVENTCHECKER_TEST is defined (either in the project or in the file). This will allow
 * you to check you event detectors in their own project, and then leave them untouched
 * for your project unless you need to alter their post functions.
 *
 * Created on September 27, 2013, 8:37 AM
 */

/*******************************************************************************
 * MODULE #INCLUDE                                                             *
 ******************************************************************************/

#include <stdio.h>
#include <BOARD.h>
#include <serial.h>
#include "xc.h"
#include "AD.h"
//#include <stdio.h>
#include "ES_Configure.h"
#include "ES_Events.h"
#include "EventChecker.h"
#include "pwm.h"
#include "IO_Ports.h"
#include "RC_Servo.h"
#include "DriveBase.h"
#include "LED.h"
#include "SimpleService.h"
#include "TemplateFSM.h"
#include "mainHSM.h"


/*******************************************************************************
 * MODULE #DEFINES                                                             *
 ******************************************************************************/
#define BATTERY_DISCONNECT_THRESHOLD 175

//#define TRACKWIRE_PIN AD_PORTW4 // AC pin definition

/*******************************************************************************
 * EVENTCHECKER_TEST SPECIFIC CODE                                                             *
 ******************************************************************************/

//#define EVENTCHECKER_TEST
#ifdef EVENTCHECKER_TEST
#include <stdio.h>
#define SaveEvent(x) do {eventName=__func__; storedEvent=x;} while (0)

static const char *eventName;
static ES_Event storedEvent;
#endif

/*******************************************************************************
 * PRIVATE FUNCTION PROTOTYPES                                                 *
 ******************************************************************************/
/* Prototypes for private functions for this EventChecker. They should be functions
   relevant to the behavior of this particular event checker */

/*******************************************************************************
 * PRIVATE MODULE VARIABLES                                                    *
 ******************************************************************************/

/* Any private module level variable that you might need for keeping track of
   events would be placed here. Private variables should be STATIC so that they
   are limited in scope to this module. */

/*******************************************************************************
 * PUBLIC FUNCTIONS                                                            *
 ******************************************************************************/

/**
 * @Function TemplateCheckBattery(void)
 * @param none
 * @return TRUE or FALSE
 * @brief This function is a prototype event checker that checks the battery voltage
 *        against a fixed threshold (#defined in the .c file). Note that you need to
 *        keep track of previous history, and that the actual battery voltage is checked
 *        only once at the beginning of the function. The function will post an event
 *        of either BATTERY_CONNECTED or BATTERY_DISCONNECTED if the power switch is turned
 *        on or off with the USB cord plugged into the Uno32. Returns TRUE if there was an 
 *        event, FALSE otherwise.
 * @note Use this code as a template for your other event checkers, and modify as necessary.
 * @author Gabriel H Elkaim, 2013.09.27 09:18
 * @modified Gabriel H Elkaim/Max Dunne, 2016.09.12 20:08 */
//uint8_t CheckBattery(void) {
//    static ES_EventTyp_t lastEvent = BATTERY_DISCONNECTED;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    uint8_t returnVal = FALSE;
//    uint16_t batVoltage = AD_ReadADPin(BAT_VOLTAGE); // read the battery voltage
//
//    if (batVoltage > BATTERY_DISCONNECT_THRESHOLD) { // is battery connected?
//        curEvent = BATTERY_CONNECTED;
//    } else {
//        curEvent = BATTERY_DISCONNECTED;
//    }
//    if (curEvent != lastEvent) { // check for change from last time
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = batVoltage;
//        returnVal = TRUE;
//        lastEvent = curEvent; // update history
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif   
//    }
//    return (returnVal);
//}
//
//uint8_t ReadTopRightBumper(void){
//    //printf("\r\nTop Right bumper checker called\r\n");
//    static ES_EventTyp_t lastEvent = BUMPERNOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTV05_TRIS = 1;
//    unsigned int rawVal = TOPRIGHTBUMP_V5;
//    
//    //printf("\r\n Raw value of top bumper: %u\r\n",rawVal);
//    if (rawVal == 1){
//        curEvent = FRONTRIGHT_TOGGLED;
//    } else{
//        curEvent = BUMPERNOTTOGGLED;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
//uint8_t ReadTopLeftBumper(void){
//    //printf("\r\nTop Right bumper checker called\r\n");
//    static ES_EventTyp_t lastEvent = BUMPERNOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTV06_TRIS = 1;
//    unsigned int rawVal = TOPLEFTBUMP_V6;
//    
//    //printf("\r\n Raw value of top bumper: %u\r\n",rawVal);
//    if (rawVal == 1){
//        curEvent = FRONTLEFT_TOGGLED;
//    } else{
//        curEvent = BUMPERNOTTOGGLED;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
//uint8_t ReadBotRightBumper(void){
//    //printf("\r\nTop Right bumper checker called\r\n");
//    static ES_EventTyp_t lastEvent = BUMPERNOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTV07_TRIS = 1;
//    unsigned int rawVal = BOTRIGHTBUMP_V7;
//    
//    //printf("\r\n Raw value of top bumper: %u\r\n",rawVal);
//    if (rawVal == 1){
//        curEvent = REARRIGHT_TOGGLED;
//    } else{
//        curEvent = BUMPERNOTTOGGLED;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
//uint8_t ReadBotLeftBumper(void){
//    //printf("\r\nTop Right bumper checker called\r\n");
//    static ES_EventTyp_t lastEvent = BUMPERNOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTV08_TRIS = 1;
//    unsigned int rawVal = BOTLEFTBUMP_V8;
//    
//    //printf("\r\n Raw value of top bumper: %u\r\n",rawVal);
//    if (rawVal == 1){
//        curEvent = REARLEFT_TOGGLED;
//    } else{
//        curEvent = BUMPERNOTTOGGLED;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
uint8_t ReadBumper(void){
    static ES_EventTyp_t lastEvent;
    uint8_t returnVal = FALSE;
    static uint8_t prevBump = 0;
    ES_EventTyp_t curEvent;
    ES_Event thisEvent;
   
    LED_AddBanks( LED_BANK2);
    // for bumper
    
    
    
    unsigned int totalVal = ((TOPLEFTBUMP_V8) << 3) |((TOPRIGHTBUMP_V7) << 2) |((FRONTLEFTBUMP_V6) << 1) | (FRONTRIGHTBUMP_V5);

    
    //printf("Bumper Tape: %u\r\n", PORTV05_BIT);

    
    if (totalVal > prevBump){
        thisEvent.EventType = BUMPERTOGGLED;
       
        thisEvent.EventParam = totalVal;
        lastEvent = curEvent;
        prevBump = totalVal;
        returnVal = TRUE;
        PostMainHSM(thisEvent);
    } else if (totalVal < prevBump) {
        thisEvent.EventType = BUMPERUNTOGGLED;
        
        thisEvent.EventParam = totalVal;
        lastEvent = curEvent;
        prevBump = totalVal;
        returnVal = TRUE;
        PostMainHSM(thisEvent);
    }
    return (returnVal);

}


//
//uint8_t ReadBotRightTape(void){
//    static ES_EventTyp_t lastEvent = TAPENOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTX03_TRIS = 1;
//    unsigned int rawVal = BOTRIGHTTAPE_X3;
//    
//    //printf("BotRight Tape: %u\r\n", rawVal);
//
//    if (rawVal == 1){
//        curEvent = BOTRIGHTTAPE_TOGGLED;
//        //printf("Cant see shit \n");
//        //returnVal = TRUE;
//    } else{
//        curEvent = TAPENOTTOGGLED;
//         //printf(" see shit \n");
//        //returnVal = FALSE;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    
//}
//
//uint8_t ReadBotLeftTape(void){
//    static ES_EventTyp_t lastEvent = TAPENOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTX05_TRIS = 1;
//    unsigned int rawVal = BOTLEFTTAPE_X5;
//    
//    //printf("BotRight Tape: %u\r\n", rawVal);
//
//    if (rawVal == 1){
//        curEvent = BOTLEFTTAPE_TOGGLED;
//        //printf("Cant see shit \n");
//        //returnVal = TRUE;
//    } else{
//        curEvent = TAPENOTTOGGLED;
//         //printf(" see shit \n");
//        //returnVal = FALSE;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//}
//uint8_t ReadTopRightTape(void){
//    static ES_EventTyp_t lastEvent = TAPENOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTX04_TRIS = 1;
//    unsigned int rawVal = TOPRIGHTTAPE_X4;
//    
//    //printf("BotRight Tape: %u\r\n", rawVal);
//
//    if (rawVal == 1){
//        curEvent = TOPRIGHTTAPE_TOGGLED;
//        //printf("Cant see shit \n");
//        //returnVal = TRUE;
//    } else{
//        curEvent = TAPENOTTOGGLED;
//         //printf(" see shit \n");
//        //returnVal = FALSE;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//
//    
//}
//uint8_t ReadTopLeftTape(void){
//    static ES_EventTyp_t lastEvent = TAPENOTTOGGLED;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    PORTX06_TRIS = 1;
//    unsigned int rawVal = TOPLEFTTAPE_X6;
//    
//    //printf("BotRight Tape: %u\r\n", rawVal);
//
//    if (rawVal == 1){
//        curEvent = TOPLEFTTAPE_TOGGLED;
//        //printf("Cant see shit \n");
//        //returnVal = TRUE;
//    } else{
//        curEvent = TAPENOTTOGGLED;
//         //printf(" see shit \n");
//        //returnVal = FALSE;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//
//}
uint8_t ReadTapeSensors(void){
    
    static ES_EventTyp_t lastEvent = TAPEUNTOGGLED;
    uint8_t returnVal = FALSE;
    static uint8_t prevTape = 0xF;
    ES_EventTyp_t curEvent;
    ES_Event thisEvent;
   
    unsigned int totalVal = TOPLEFTTAPE_X6 << 3 | TOPRIGHTTAPE_X4 << 2 | BOTLEFTTAPE_X5 << 1 | BOTRIGHTTAPE_X3;
    
    //printf("BotRight Tape: %u\r\n", rawVal);

    
    if (totalVal > prevTape){
        thisEvent.EventType = TAPETOGGLED;
        thisEvent.EventParam = totalVal;
        lastEvent = curEvent;
        prevTape = totalVal;
        returnVal = TRUE;
        PostMainHSM(thisEvent);
    } else if (totalVal < prevTape){
        thisEvent.EventType = TAPEUNTOGGLED;
        thisEvent.EventParam = totalVal ^ prevTape;
        lastEvent = curEvent;
        prevTape = totalVal;
        returnVal = TRUE;
        PostMainHSM(thisEvent);
    }
}

//
//uint8_t Trackwire_Detection(void){
//    
//    LED_AddBanks(LED_BANK1 | LED_BANK2 | LED_BANK3);
//    static ES_EventTyp_t lastEvent = TRACKWIRE_LO_THRESH;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    static unsigned int Threshold = TRACKWIRE_HI_THRESH;
//   
//    uint16_t rawVal = AD_ReadADPin(TRACK_WIRE1_PIN);
//    
//    //printf("The ADC value being read is %d. \r\n", rawVal);
//
//
//    if (rawVal > Threshold){
//        curEvent = TRACKWIRE_DETECTED;
//        LED_SetBank(LED_BANK1, 0b1111);
//        Threshold = TRACKWIRE_LO_THRESH;
//        
//    }  else{
//        LED_SetBank(LED_BANK1, 0b0000);
//        curEvent = TRACKWIRE_UNDETECTED;
//        Threshold = TRACKWIRE_HI_THRESH;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostSimpleService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//}
//uint8_t Trackwire2_Detection(void){
//    static ES_EventTyp_t lastEvent = TRACKWIRE2_LO_THRESH;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    static unsigned int Threshold = TRACKWIRE2_HI_THRESH;
//   
//    uint16_t rawVal = AD_ReadADPin(AD_PORTW3);
//    
//    //printf("The ADC value being read is %d. \r\n", rawVal);
//
//
//    if (rawVal > Threshold){
//        curEvent = TRACKWIRE2_DETECTED;
//        Threshold = TRACKWIRE2_LO_THRESH;
//        
//    }  else{
//        curEvent = TRACKWIRE2_UNDETECTED;
//        Threshold = TRACKWIRE2_HI_THRESH;
//    }
//    if (curEvent != lastEvent){
//        thisEvent.EventType = curEvent;
//        thisEvent.EventParam = rawVal;
//        returnVal = TRUE;
//        lastEvent = curEvent;
//
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostMainHSM(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif
//    }
//    return (returnVal);
//    
//}
//uint8_t TrackWireEventCheck(void) {
//	
//	// initializing into the dark
//	static uint8_t lastTrackWireState = NO_TRACKWIRE; 
//    
//	
//	// read current light level (the numerical value)
//	unsigned int currentVal = AD_ReadADPin(TRACKWIRE_PIN);
//    PORTZ04_TRIS = 0;
//    PORTZ04_BIT = 1;
//    printf("The tape sensor reading from the ADC is %d. \r\n", currentVal);
//	uint8_t currentTrackWireState;
//    
//	ES_Event trackWireEvent; 
//	uint8_t eventStatus = FALSE;
//	uint16_t trackWireEventParam = 0; 
//	
//	// light level has dipped below the lower (light) threshold
//	if (currentVal < TRACKWIRE_LO_THRESH){
//        currentTrackWireState = TRACKWIRE;
//    } 
//	// light level has climbed aboe the upper (dark) threshold
//	else if (currentVal > TRACKWIRE_LO_THRESH){
//        currentTrackWireState = NO_TRACKWIRE;
//    } 
//	// If between the thresholds, set the current light state to the previous light state
//	else{ 
//        currentTrackWireState = lastTrackWireState;
//    }
//    
//    if ((currentTrackWireState != lastTrackWireState) && (currentTrackWireState == TRACKWIRE)){
//		// numerical light level in parameter
//        trackWireEvent.EventType = TRACKWIRE_DETECTED;
//		trackWireEvent.EventParam = currentVal;
//		
//		#ifndef EVENTCHECKER_TEST          
//        PostGenericService(trackWireEvent);
//		#else
//        SaveEvent(trackWireEvent);
//		#endif 
//		
//        eventStatus = TRUE;
//    } else if ((currentTrackWireState != lastTrackWireState) && (currentTrackWireState == NO_TRACKWIRE)){
//		// numerical light level in parameter
//        trackWireEvent.EventType = TRACKWIRE_UNDETECTED;
//		trackWireEvent.EventParam = currentVal; 
//		
//		#ifndef EVENTCHECKER_TEST          
//        PostGenericService(trackWireEvent);
//		#else
//        SaveEvent(trackWireEvent);
//		#endif 
//		
//        eventStatus = TRUE;
//    } else { //no change
//        eventStatus = FALSE; //not really needed
//    }
//    
//    lastTrackWireState = currentTrackWireState;
//    return eventStatus;
//}

//// for part5
//uint8_t lightCheck(void){
//    static ES_EventTyp_t lastEvent = FALL_NO_TRACKWIRENESS;
//    uint8_t returnVal = FALSE;
//    ES_EventTyp_t curEvent;
//    ES_Event thisEvent;
//    unsigned int lightlevel = Roach_LightLevel();
//    if (lightlevel < TRACKWIRE_THRESH){
//        curEvent = SEE_TRACKWIRE;
//    } else{
//        curEvent = FALL_NO_TRACKWIRENESS;
//    }
//    if (curEvent != lastEvent){
//    thisEvent.EventType = curEvent;
//    thisEvent.EventParam = lightlevel;
//    returnVal = TRUE;
//    lastEvent = curEvent;
//    printf("\r\nEvent: %s\tParam: 0x%X",
//        EventNames[thisEvent.EventType], thisEvent.EventParam);
//#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//        PostGenericService(thisEvent);
//#else
//        SaveEvent(thisEvent);
//#endif   
//    }
//    return (returnVal);
//}

/* 
 * The Test Harness for the event checkers is conditionally compiled using
 * the EVENTCHECKER_TEST macro (defined either in the file or at the project level).
 * No other main() can exist within the project.
 * 
 * It requires a valid ES_Configure.h file in the project with the correct events in 
 * the enum, and the correct list of event checkers in the EVENT_CHECK_LIST.
 * 
 * The test harness will run each of your event detectors identically to the way the
 * ES_Framework will call them, and if an event is detected it will print out the function
 * name, event, and event parameter. Use this to test your event checking code and
 * ensure that it is fully functional.
 * 
 * If you are locking up the output, most likely you are generating too many events.
 * Remember that events are detectable changes, not a state in itself.
 * 
 * Once you have fully tested your event checking code, you can leave it in its own
 * project and point to it from your other projects. If the EVENTCHECKER_TEST marco is
 * defined in the project, no changes are necessary for your event checkers to work
 * with your other projects.
 */
#ifdef EVENTCHECKER_TEST
#include <stdio.h>
static uint8_t(*EventList[])(void) = {EVENT_CHECK_LIST};

void PrintEvent(void);

void main(void) {
    //BOARD_Init();
    //BOARD_Init(); // Board
    //AD_Init(); // AD Pins
    //LED_Init();
    
//     Setup
//    AD_AddPins(AD_PORTV3);
//    PORTZ05_TRIS = 0;
//    PORTZ05_BIT = 1;
//    AD_AddPins(AD_PORTV4);
//    PORTZ07_TRIS = 0;
//    PORTZ07_LAT = 1;
//    AD_AddPins(AD_PORTV5);
    //PORTZ04_TRIS = 1;
//    PORTY03_TRIS = 0;
//    PORTY03_LAT = 1;
  
    DriveBase_Init(); 
    
    /* user initialization code goes here */
    //DriveBase_Init();
    
   

    // Do not alter anything below this line
    int i;

    printf("\r\nEvent checking test harness for %s", __FILE__);

    while (1) {
        if (IsTransmitEmpty()) {
//            for(int x = 0; x<150000; x++){
//                asm("nop");
//           }
            for (i = 0; i< sizeof (EventList) >> 2; i++) {
                if (EventList[i]() == TRUE) {
                    PrintEvent();
                    break;
                }

            }
        }
    }
}

void PrintEvent(void) {
    printf("\r\nFunc: %s\tEvent: %s\tParam: 0x%X", eventName,
            EventNames[storedEvent.EventType], storedEvent.EventParam);
}
#endif